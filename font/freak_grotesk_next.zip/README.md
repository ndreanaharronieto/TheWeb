# FREAK-GROTESK-NEXT.vfb and .otf 

Open Source Development for new glyphs in FontLab Studio 

Freak Grotesk Next is a Responsive Typeface with multiple glyphs and Open Type custom Functions

The Font was designed during a collaborative workshop called XYZ 2017 in Bari (Italy) @ La Scuola Open Source  

X-TYPE 2017 - Tutors: Daniele Capo and Alessio D'Ellena / Type Designers

Participants: Chiara Bagnardi - Valentina Caldarola - Aureliano Capri - Fabrizio Jimenez - Bianca Laterza - Micol Salomone 

Owner: La Scuola Open Source [ www.lascuolaopensource.xyz ]

# NOTE: This .vfb and .otf files are distributed under a SIL Open Font License ( see the LICENSE.txt file ) more info on: http://scripts.sil.org/cms/scripts/page.php?item_id=OFL

NOTE2: All the contributors' details are filled under the CREDITS.txt file, if you are willing to participate to this repository - for example if you want to design new glyphs for this Typeface or if you've noticed for some bugs needing to be fixed - you can insert your name and details into this file after submitting it :)
